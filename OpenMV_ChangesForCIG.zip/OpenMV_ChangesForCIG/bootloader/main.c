/*
 * This file is part of the OpenMV project.
 *
 * Copyright (c) 2013-2021 Ibrahim Abdelkader <iabdalkader@openmv.io>
 * Copyright (c) 2013-2021 Kwabena W. Agyeman <kwagyeman@openmv.io>
 *
 * This work is licensed under the MIT license, see the file LICENSE for details.
 *
 * main function.
 */
#include STM32_HAL_H
#include "usbdev/usbd_cdc.h"
#include "usbdev/usbd_desc.h"
#include "omv_boardconfig.h"
#include "qspif.h"

#define NO_BLINKS  (1)  
#define REGISTER_DIAGS (0)
#define IDE_TIMEOUT     (1000)
#define CONFIG_TIMEOUT  (2000)
#define LED_PORT GPIOC
#define LED_PIN 1<<2
USBD_HandleTypeDef  USBD_Device;
extern USBD_CDC_ItfTypeDef  USBD_CDC_fops;
char hex1ToAscii(char); 
void uartRegDump(int , char , UART_HandleTypeDef ); 

void __flash_led()
{
    if(!NO_BLINKS){
        HAL_GPIO_TogglePin(LED_PORT, LED_PIN);
        HAL_Delay(100);
        HAL_GPIO_TogglePin(LED_PORT, LED_PIN);
        HAL_Delay(100);
    }
}

void __attribute__((noreturn)) __fatal_error()
{
    while (1) {
        __flash_led();
    }
}

#ifdef STACK_PROTECTOR
uint32_t __stack_chk_guard=0xDEADBEEF;

void __attribute__((noreturn)) __stack_chk_fail(void)
{
    __asm__ volatile ("BKPT");
    while (1) {
        __flash_led();
    }
}

#endif

int main()
{
    // Override main app interrupt vector offset (set in system_stm32fxxx.c)
    SCB->VTOR = FLASH_BASE | 0x0;

     HAL_Init(); //for HAL_Delay() also need to enable interrupts. //this seems to take the function from stm32h7xx_hal.c. DBonham Feb 2022 (not the stm32f...)
    GPIO_InitTypeDef GPIO_InitStruct = {0}; //DBonham Aug 2021

    GPIO_InitStruct.Pin = LED_PIN /*OMV_BOOTLDR_LED_PIN*/;//
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;//
    GPIO_InitStruct.Pull = GPIO_NOPULL;//
    GPIO_InitStruct.Speed= GPIO_SPEED_FREQ_LOW;//
    HAL_GPIO_Init(LED_PORT, &GPIO_InitStruct);//
    HAL_GPIO_WritePin(LED_PORT, LED_PIN, 0);

 /*   HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_1);
    HAL_Delay(400);
    HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_1);
    HAL_Delay(100);
    HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_1);
    HAL_Delay(100);
    HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_1);*/
 
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_UART5_CLK_ENABLE(); //REQUIRED!!
    static UART_HandleTypeDef huart5;
    GPIO_InitStruct.Pin = GPIO_PIN_12 | GPIO_PIN_13; //
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;        //s
    GPIO_InitStruct.Pull = GPIO_NOPULL;            //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;   //
    GPIO_InitStruct.Alternate = GPIO_AF14_UART5;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct); //
    __HAL_RCC_UART5_CLK_ENABLE(); //REQUIRED!!
    huart5.Instance = UART5;
    huart5.Init.BaudRate = 9600;
    huart5.Init.WordLength = UART_WORDLENGTH_8B;
    huart5.Init.StopBits = UART_STOPBITS_1;
    huart5.Init.Parity = UART_PARITY_NONE;
    huart5.Init.Mode = UART_MODE_TX_RX;
    huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart5.Init.OverSampling = UART_OVERSAMPLING_16;
    huart5.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
    huart5.Init.ClockPrescaler = UART_PRESCALER_DIV1;
    huart5.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
    HAL_UART_Init(&huart5);
    HAL_UART_Transmit(&huart5, (unsigned char*)("\r\nBTLD\r\n"), 8, 100);
 
//    if(REGISTER_DIAGS){
//    uartRegDump((int)(&(RTC->TR)), 1, huart2);   //  
//      uartRegDump((int)(&(RTC->CR)), 1, huart2);   //  DON'T READ THESE RTC REGISTERS BECAUSE IT'LL RESET THE DATE-TIME!!!!
//      uartRegDump((int)(&(RTC->ISR)), 1, huart2);   //  
//    uartRegDump((int)(&(RCC->BDCR)), 1, huart2);   // 
//    uartRegDump((int)(&(PWR->WKUPFR)), 1, huart2);   // 
//    uartRegDump((int)(&(RTC->ISR)), 1, huart2);   // 
//    uartRegDump((int)(&(RCC->BDCR)), 1, huart2);   // 
//    }
    /****  END UART DEBUG INIT *****/

    #if defined(OMV_QSPIF_LAYOUT)
    if (qspif_init() != 0) {
        __fatal_error();
    }
    #endif

    /* Init Device Library */
    USBD_Init(&USBD_Device, &VCP_Desc, 0);

    /* Add Supported Class */
    USBD_RegisterClass(&USBD_Device, USBD_CDC_CLASS);

    /* Add CDC Interface Class */
    USBD_CDC_RegisterInterface(&USBD_Device, &USBD_CDC_fops);

    /* Start Device Process */
    USBD_Start(&USBD_Device);

    // Note: The SRQINT interrupt is triggered when VBUS is in the valid range, I assume it's safe
    // to use it to detect if USB is connected or not. The dev_connection_status is set in usbd_conf.c
    // It wasn't used anywhere else, so again assuming it's safe to use it for connection status.
    if (USBD_Device.dev_connection_status) {
        uint32_t start = HAL_GetTick();
        // Wait for device to be configured
        while (USBD_Device.dev_state != USBD_STATE_CONFIGURED
                // We still have to timeout because the camera
                // might be connected to a power bank or charger
                && (HAL_GetTick() - start) < CONFIG_TIMEOUT) {
            __flash_led();
        }

        // If the device is configured, wait for IDE to connect or timeout
        if (USBD_Device.dev_state == USBD_STATE_CONFIGURED) {
            uint32_t start = HAL_GetTick();
            while (!USBD_IDE_Connected()
                    && (HAL_GetTick() - start) < IDE_TIMEOUT) {
                __flash_led();
            }

            // Wait for new firmware image if the IDE is connected
            while (USBD_IDE_Connected()) {
                __flash_led();
            }
        }
    }

    // Deinit USB
    USBD_DeInit(&USBD_Device);

    #if defined(OMV_QSPIF_LAYOUT)
    qspif_reset();
    qspif_deinit();
    #endif

    // Disable IRQs
    __disable_irq(); __DSB(); __ISB();

    // Jump to main app
    ((void (*)(void))(*((uint32_t*) (MAIN_APP_ADDR+4))))();
}

/*******************************************************************/
/*   UART REGISTER DUMP BOOTLOADER                                           */
/*******************************************************************/
void uartRegDump(int startAddress, char numRegs, UART_HandleTypeDef lochuart)
{
    uint8_t regPacket[12];
    uint8_t addrPacket[9];
    uint32_t iters;
    uint8_t returnArray[2];
    uint32_t regContents;
    returnArray[0] = 0x0A;
    returnArray[1] = 0x0D;
    regPacket[2] = ' ';
    regPacket[5] = ' ';
    regPacket[8] = ' ';
    HAL_UART_Transmit(&lochuart, returnArray, 2, 100);
    for (iters = 0; iters < (numRegs * 4); iters += 4)
    {
        addrPacket[0] = (char)(hex1ToAscii((char)((startAddress >> 28) & 0x00FF)));
        addrPacket[1] = (char)(hex1ToAscii((char)((startAddress >> 24) & 0x00FF)));
        addrPacket[2] = (char)(hex1ToAscii((char)((startAddress >> 20) & 0x00FF)));
        addrPacket[3] = (char)(hex1ToAscii((char)((startAddress >> 16) & 0x00FF)));
        addrPacket[4] = (char)(hex1ToAscii((char)((startAddress >> 12) & 0x00FF)));
        addrPacket[5] = (char)(hex1ToAscii((char)((startAddress >> 8) & 0x00FF)));
        addrPacket[6] = (char)(hex1ToAscii((char)((startAddress >> 4) & 0x00FF)));
        addrPacket[7] = (char)(hex1ToAscii((char)((startAddress)&0x00FF)));
        addrPacket[8] = ' ';

        regContents = *((int *)(startAddress));
        regPacket[0] = (char)(hex1ToAscii((char)((regContents >> 28) & 0x00FF)));
        regPacket[1] = (char)(hex1ToAscii((char)((regContents >> 24) & 0x00FF)));
        regPacket[3] = (char)(hex1ToAscii((char)((regContents >> 20) & 0x00FF)));
        regPacket[4] = (char)(hex1ToAscii((char)((regContents >> 16) & 0x00FF)));
        regPacket[6] = (char)(hex1ToAscii((char)((regContents >> 12) & 0x00FF)));
        regPacket[7] = (char)(hex1ToAscii((char)((regContents >> 8) & 0x00FF)));
        regPacket[9] = (char)(hex1ToAscii((char)((regContents >> 4) & 0x00FF)));
        regPacket[10] = (char)(hex1ToAscii((char)((regContents)&0x00FF)));

        startAddress += 4;
        HAL_UART_Transmit(&lochuart, addrPacket, 9, 100);
        HAL_UART_Transmit(&lochuart, regPacket, 11, 100);
        HAL_UART_Transmit(&lochuart, returnArray, 2, 100);
    }
}
/***********************************************************************/
/*  hex1ToAscii nibble to 1-byte Ascii  */
/***********************************************************************/
char hex1ToAscii(char hex)
{
    int a;
    hex &= 0x000F;
    switch (hex)
    {
    case 0:
        a = 0x30;
        break;
    case 1:
        a = 0x31;
        break;
    case 2:
        a = 0x32;
        break;
    case 3:
        a = 0x33;
        break;
    case 4:
        a = 0x34;
        break;
    case 5:
        a = 0x35;
        break;
    case 6:
        a = 0x36;
        break;
    case 7:
        a = 0x37;
        break;
    case 8:
        a = 0x38;
        break;
    case 9:
        a = 0x39;
        break;
    case 10:
        a = 0x41;
        break;
    case 11:
        a = 0x42;
        break;
    case 12:
        a = 0x43;
        break;
    case 13:
        a = 0x44;
        break;
    case 14:
        a = 0x45;
        break;
    case 15:
        a = 0x46;
        break;
    };
    return a;
}