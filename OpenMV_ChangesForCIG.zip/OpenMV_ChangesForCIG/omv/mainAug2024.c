/*
 * This file is part of the OpenMV project.
 *
 * Copyright (c) 2013-2021 Ibrahim Abdelkader <iabdalkader@openmv.io>
 * Copyright (c) 2013-2021 Kwabena W. Agyeman <kwagyeman@openmv.io>
 *
 * This work is licensed under the MIT license, see the file LICENSE for details.
 *
 * main function.
 */
/*********** BEGIN FDT ************/
#define DO_DIAGS
#define UART_DEBUGS 1	//sends debugs in addition to LRW packets out the same UART
#define PRINT_DEBUGS (1) // Sends debug info to the Serial Terminal window at the bottom of OpenMV UI. Normally off (False) for field deployments.
#define BLINK_ONLY_PWR_BOOT (1)
#define DO_EEPROM_TEST (0)
#define WU_STM_PORT GPIOA
#define WU_STM_PIN 1<<2
#define STM_SAM_DAT_PORT GPIOB
#define STM_SAM_DAT_PIN 1<<0
#define STM_SAM_CLK_PORT GPIOG
#define STM_SAM_CLK_PIN 1<<12
#define WU_SAM_PORT GPIOA
#define WU_SAM_PIN 1<<3
#define LCD_SI_PORT GPIOJ
#define LCD_SI_PIN 1<<11
#define LCD_SCL_PORT GPIOD
#define LCD_SCL_PIN 1<<11
#define LCD_RS_PORT GPIOE
#define LCD_RS_PIN 1<<3
#define LCD_PWRC_PORT GPIOG
#define LCD_PWRC_PIN 1<<9
#define SENSOR_PWRC_PORT GPIOK
#define SENSOR_PWRC_PIN 1<<1
#define SENSOR_SDA_PORT GPIOB
#define SENSOR_SDA_PIN 1<<11
#define SENSOR_SCL_PORT GPIOB
#define SENSOR_SCL_PIN 1<<10
#define LED_PORT GPIOC
#define LED_PIN 1<<1
#define CAM_PWRC_PORT GPIOD
#define CAM_PWRC_PIN 1<<3
#define BUTTON_LEFT_PORT GPIOA
#define BUTTON_LEFT_PIN 1<<0
#define BUTTON_OK_PORT GPIOC
#define BUTTON_OK_PIN 1<<13
#define BUTTON_RIGHT_PORT GPIOI
#define BUTTON_RIGHT_PIN 1<<11
#define LRW_PWRC_PORT GPIOC
#define LRW_PWRC_PIN 1<<3
#define EEPROM_SDA_PIN 1<<13
#define EEPROM_SCL_PIN 1<<12
#define EEPROM_PORT GPIOD
#define SDIO_PWRC_PORT GPIOK
#define SDIO_PWRC_PIN 1<<2
#define CAM_FLASH_A_PORT GPIOE
#define CAM_FLASH_A_PIN 1<<2
#define CAM_FLASH_B_PORT GPIOK
#define CAM_FLASH_B_PIN 1<<4
#define FILTER_SW_A_PORT GPIOG
#define FILTER_SW_A_PIN 1<<14
#define FILTER_SW_B_PORT GPIOD
#define FILTER_SW_B_PIN 1<<4
#define WU_STM_PORT GPIOA
#define WU_STM_PIN 1<<2
#define STM_SAM_DAT_PORT GPIOB
#define STM_SAM_DAT_PIN 1<<0
#define STM_SAM_CLK_PORT GPIOG
#define STM_SAM_CLK_PIN 1<<12
#define WU_SAM_PORT GPIOA
#define WU_SAM_PIN 1<<3
#define LED_PORT GPIOC
#define LED_PIN 1<<1
#define EE_I2C_DELAY (20)	//ALSO DEFINED IN platform.c
/*********** END FDT ************/
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include STM32_HAL_H
#include "mpconfig.h"
#include "systick.h"
#include "pendsv.h"
#include "qstr.h"
#include "nlr.h"
#include "lexer.h"
#include "parse.h"
#include "compile.h"
#include "runtime.h"
#include "obj.h"
#include "objmodule.h"
#include "objstr.h"
#include "gc.h"
#include "stackctrl.h"
#include "gccollect.h"
#include "timer.h"
#include "pin.h"
#include "usb.h"
#include "rtc.h"
#include "storage.h"
#include "sdcard.h"
#include "modmachine.h"
#include "extmod/modnetwork.h"
#include "extmod/modmachine.h"

#include "extmod/vfs.h"
#include "extmod/vfs_fat.h"
#include "shared/runtime/pyexec.h"
#include "shared/readline/readline.h"

#include "irq.h"
#include "rng.h"
#include "led.h"
#include "spi.h"
#include "i2c.h"
#include "uart.h"
#include "dac.h"
#include "can.h"
#include "extint.h"
#include "servo.h"

#include "sensor.h"
#include "usbdbg.h"
#include "wifidbg.h"
#include "sdram.h"
#include "fb_alloc.h"
#include "dma_alloc.h"
#include "file_utils.h"

#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_cdc_msc_hid.h"
#include "usbd_cdc_interface.h"

#include "py_image.h"
#include "py_fir.h"
#include "py_tv.h"
#include "py_buzzer.h"
#include "py_imu.h"
#include "py_audio.h"

#include "framebuffer.h"

#include "ini.h"
#include "omv_boardconfig.h"
#include "omv_gpio.h"
#include "omv_i2c.h"

#if MICROPY_PY_LWIP
#include "lwip/init.h"
#include "lwip/apps/mdns.h"
#include "lib/cyw43-driver/src/cyw43.h"
#endif

#if MICROPY_PY_BLUETOOTH
#include "extmod/modbluetooth.h"
#include "mpbthciport.h"
#endif

#include "extmod/vfs.h"
#include "extmod/vfs_fat.h"
#include "boot_utils.h"

/********** MYFUNCS ********/
#include "FDT_utilities.h"
UART_HandleTypeDef huart5;
void LCDoff(void);
void ledBlink (unsigned char);
void UARTspace(void);
void UARTshort(short, char);
void eepromSDA_OUTlow(void);
void eepromSCL_OUTlow(void);
void eepromSDA_OUT(void);
void eepromSCL_OUT(void);
void eepromSDA_INpull(void);
void eepromSCL_INpull(void);
void write_sda_EE (unsigned char);
unsigned char twi_stop_cond_EE(void);
unsigned char twi_start_cond_EE(void);
void eepromWriteWakeUpSource(unsigned char);
unsigned char i2c_write_byte_EE(unsigned char, unsigned char);
/******* END MYFUNCS ********/

int errno;
extern char _vfs_buf[];
static fs_user_mount_t *vfs_fat = (fs_user_mount_t *) &_vfs_buf;
#if MICROPY_PY_THREAD
pyb_thread_t pyb_thread_main;
#endif

void flash_error(int n) {
    led_state(LED_RED, 0);
    led_state(LED_GREEN, 0);
    led_state(LED_BLUE, 0);
    for (int i = 0; i < n; i++) {
        led_state(LED_RED, 0);
        HAL_Delay(100);
        led_state(LED_RED, 1);
        HAL_Delay(100);
    }
    led_state(LED_RED, 0);
}

void NORETURN __fatal_error(const char *msg) {
    // Check if any storage has been initialized
    // before attempting to create the error log.
    if (pyb_usb_storage_medium) {
        FIL fp;
        if (f_open(&vfs_fat->fatfs, &fp, "ERROR.LOG",
                   FA_WRITE | FA_CREATE_ALWAYS) == FR_OK) {
            UINT bytes;
            const char *hdr = "FATAL ERROR:\n";
            file_ll_write(&fp, hdr, strlen(hdr), &bytes);
            file_ll_write(&fp, msg, strlen(msg), &bytes);
            file_ll_close(&fp);
            storage_flush();
            // Initialize the USB device if it's not already initialize to allow
            // the host to mount the filesystem and access the error log.
            pyb_usb_dev_init(pyb_usb_dev_detect(), MICROPY_HW_USB_VID,
                             MICROPY_HW_USB_PID_CDC_MSC, USBD_MODE_CDC_MSC, 0, NULL, NULL);
        }
    }
    for (uint i = 0;;) {
        led_toggle(((i++) & 3));
        for (volatile uint delay = 0; delay < 500000; delay++) {
        }
    }
}

void nlr_jump_fail(void *val) {
    printf("FATAL: uncaught exception %p\n", val);
    __fatal_error("");
}

#ifndef NDEBUG
void __attribute__((weak)) __assert_func(const char *file, int line, const char *func, const char *expr) {
    (void) func;
    printf("Assertion '%s' failed, at file %s:%d\n", expr, file, line);
    __fatal_error("");
}
#endif

#ifdef STACK_PROTECTOR
uint32_t __stack_chk_guard = 0xDEADBEEF;

void NORETURN __stack_chk_fail(void) {
    while (1) {
        flash_error(100);
    }
}
#endif

typedef struct openmv_config {
    bool wifidbg;
    wifidbg_config_t wifidbg_config;
} openmv_config_t;

int ini_handler_callback(void *user, const char *section, const char *name, const char *value) {
    openmv_config_t *openmv_config = (openmv_config_t *) user;

#define MATCH(s, n)    ((strcmp(section, (s)) == 0) && (strcmp(name, (n)) == 0))

    if (MATCH("BoardConfig", "REPLUart")) {
        if (ini_is_true(value)) {
            mp_obj_t args[2] = {
                MP_OBJ_NEW_SMALL_INT(3), // UART Port
                MP_OBJ_NEW_SMALL_INT(115200) // Baud Rate
            };

            MP_STATE_PORT(pyb_stdio_uart) = MP_OBJ_TYPE_GET_SLOT(&machine_uart_type, make_new) (
                (mp_obj_t) &machine_uart_type, MP_ARRAY_SIZE(args), 0, args);
            uart_attach_to_repl(MP_STATE_PORT(pyb_stdio_uart), true);
        }
    } else if (MATCH("BoardConfig", "WiFiDebug")) {
        openmv_config->wifidbg = ini_is_true(value);
    } else if (MATCH("WiFiConfig", "Mode")) {
        openmv_config->wifidbg_config.mode = ini_atoi(value);
    } else if (MATCH("WiFiConfig", "ClientSSID")) {
        strncpy(openmv_config->wifidbg_config.client_ssid, value, WINC_MAX_SSID_LEN);
    } else if (MATCH("WiFiConfig", "ClientKey")) {
        strncpy(openmv_config->wifidbg_config.client_key,  value, WINC_MAX_PSK_LEN);
    } else if (MATCH("WiFiConfig", "ClientSecurity")) {
        openmv_config->wifidbg_config.client_security = ini_atoi(value);
    } else if (MATCH("WiFiConfig", "ClientChannel")) {
        openmv_config->wifidbg_config.client_channel = ini_atoi(value);
    } else if (MATCH("WiFiConfig", "AccessPointSSID")) {
        strncpy(openmv_config->wifidbg_config.access_point_ssid, value, WINC_MAX_SSID_LEN);
    } else if (MATCH("WiFiConfig", "AccessPointKey")) {
        strncpy(openmv_config->wifidbg_config.access_point_key,  value, WINC_MAX_PSK_LEN);
    } else if (MATCH("WiFiConfig", "AccessPointSecurity")) {
        openmv_config->wifidbg_config.access_point_security = ini_atoi(value);
    } else if (MATCH("WiFiConfig", "AccessPointChannel")) {
        openmv_config->wifidbg_config.access_point_channel = ini_atoi(value);
    } else if (MATCH("WiFiConfig", "BoardName")) {
        strncpy(openmv_config->wifidbg_config.board_name,  value, WINC_MAX_BOARD_NAME_LEN);
    } else {
        return 0;
    }

    return 1;

    #undef MATCH
}
/***********************************************************************/
/*  send UART space             										*/
/***********************************************************************/
void UARTspace(void){
	HAL_UART_Transmit(&huart5, (unsigned char*)(" "), 1, 100);
}
/***********************************************************************/
/*  send UART RETURN            										*/
/***********************************************************************/
void UARTreturn(void){
	HAL_UART_Transmit(&huart5, (unsigned char*)("\r\n"), 2, 100);
}
/***********************************************************************/
/*  send short to UART												*/
/***********************************************************************/
void UARTshort(short a, char d)
{
  	char iters,senduint8_ts[4];
 	short z,zz;
 	iters=d;
 	z=hex2ToAscii((a>>8)&0x00FF);
 	zz=hex2ToAscii(a&0x00FF);
 	senduint8_ts[d-1]=(uint8_t)zz;
 	if(--iters>0)senduint8_ts[d-2]=(uint8_t)(zz>>8);
 	if(--iters>0)senduint8_ts[d-3]=(uint8_t)(z);
 	if(--iters>0)senduint8_ts[d-4]=(uint8_t)(z>>8);
 	HAL_UART_Transmit(&huart5, (unsigned char*)senduint8_ts, d, 100);
}
  /*********************************************************/
 /* LED BLINK                                         */
 /*********************************************************/
 void ledBlink (unsigned char numBlinks){
 unsigned char iters;
    if(BLINK_ONLY_PWR_BOOT==0){
        for(iters=numBlinks;iters>0;iters--){
        //	  HAL_IWDG_Refresh(&hiwdg1);
            HAL_GPIO_WritePin(LED_PORT, LED_PIN, 0);//TP
            HAL_Delay(50);
            HAL_GPIO_WritePin(LED_PORT, LED_PIN, 1);//TP
            HAL_Delay(100);
        }
    }
 }
/*********************************************************/
 /* LED BLINK REGARDLESS OF #DEFINES                       */
 /*********************************************************/
 void ledBlinkRegardless (unsigned char numBlinks){
    unsigned char iters;
    GPIO_InitTypeDef GPIO_InitStruct = {0}; //DBonham Aug 2021

    GPIO_InitStruct.Pin = LED_PIN;                   //
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;                                   //
    GPIO_InitStruct.Pull = GPIO_NOPULL;                                           //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;                                  //
    HAL_GPIO_Init(LED_PORT, &GPIO_InitStruct);                                       //
    for(iters=numBlinks;iters>0;iters--){
    //	  HAL_IWDG_Refresh(&hiwdg1);
        HAL_GPIO_WritePin(LED_PORT, LED_PIN, 0);//TP
        HAL_Delay(50);
        HAL_GPIO_WritePin(LED_PORT, LED_PIN, 1);//TP
        HAL_Delay(100);
    }
 }
/*********************************************************
 *  WRITE SDA PIN
 *********************************************************/
 void write_sda_EE (uint8_t x)
 {
 	if(x) eepromSDA_INpull();
 	else eepromSDA_OUTlow();
 }
 /*********************************************************
 *   SEND SLAVE ADDRESS
 *********************************************************/
 uint8_t send_slave_Address_EE(uint8_t read, uint8_t slaveAddress)
 {
  	return !(i2c_write_byte_EE(slaveAddress | read, 0 ));	//write_byte returns 1, so this returns 0.
 }
 /*******************************************
*    MY DELAY (temporary until create usecond timer)
********************************************/
void myDelay(unsigned int myTicks){
 	int iters,itersInner;
 	for (iters=myTicks; iters>0; iters--){
 		for (itersInner=5/*TICKCTR*/; itersInner>0; itersInner--){}
 	}
}
/*********************************************************
 *   START CONDITION EEPROM
 *********************************************************/
 uint8_t twi_start_cond_EE(void)
 {
 	eepromSCL_INpull();
 	eepromSDA_INpull();
    myDelay(EE_I2C_DELAY);
    eepromSDA_OUTlow();
    myDelay(EE_I2C_DELAY);
    eepromSCL_OUTlow();
    myDelay(EE_I2C_DELAY);
 	return 1;
 }
 /*********************************************************
 *   STOP CONDITION EEPROM
 *********************************************************/
 uint8_t twi_stop_cond_EE(void)
 {
	eepromSCL_INpull();
//	while(HAL_GPIO_ReadPin(EEPROM_PORT, EEPROM_SCL_PIN)==0){} //wait if/while SCL is pulled low by slave stretching clock.
    myDelay(EE_I2C_DELAY);
    myDelay(EE_I2C_DELAY);
	eepromSDA_OUTlow();
    myDelay(EE_I2C_DELAY);
	eepromSDA_INpull();
 	return 1;
 }
 /*********************************************************
  * EEPROM SDA OUTPUT
  *********************************************************/
 void eepromSDA_OUT(void){
   GPIO_InitTypeDef GPIO_InitStruct = {0};
   GPIO_InitStruct.Pin = EEPROM_SDA_PIN;
   GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
   GPIO_InitStruct.Pull = GPIO_NOPULL;
   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
   HAL_GPIO_Init(EEPROM_PORT, &GPIO_InitStruct);
 }
/************************************************************************/
 /*  EEPROM WRITE ASCII LATLONG										    	*/
 /*  1FFC8: 19 bytes of ASCII Date-Time for Python image files  */
 /*  1FFDC: 4 bytes of compressed LatLong  */
 /*  1FFE0: 4 bytes of compressed LatLong  */
 /*  1FFE4:   ASCII Lat Sign   */
 /*	 1FFE5-6: ASCII Lat Whole  */
 /*	 1FFE7:   ASCII '.'        */
 /*  1FFF8-C: ASCII Lat Frac   */
 /*  1FFED:   ASCII Long Sign  */
 /*	 1FFEE-F0: ASCII Long Whole */
 /*	 1FFF1:   ASCII '.'        */
 /*  1FFF2-6: ASCII Long Frac  */
 /************************************************************************/
 void eepromWriteWakeUpSource(unsigned char wakeUpSource){
 	twi_start_cond_EE();
 	send_slave_Address_EE(0, 0xA2);//A2=I2C address for upper half of EEPROM memory
 	i2c_write_byte_EE(0xFF, 0);
 	i2c_write_byte_EE(0xC8, 0);//WRITE
 		i2c_write_byte_EE(wakeUpSource, 0);
 	twi_stop_cond_EE();
 	HAL_Delay(5);//Datasheet sasy 5ms. Empiracally needs at least 3 ms. Datasheet says can send device address repeatedly until EEPROM acks.
 }
 /*********************************************************
 *   WRITE BYTE EEPROM
 *********************************************************/
 unsigned char i2c_write_byte_EE(unsigned char byte, unsigned char stretch)
 {
 	unsigned char bit;
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = EEPROM_SCL_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(EEPROM_PORT, &GPIO_InitStruct);

	for (bit = 0; bit < 8; bit++)
 		{
             write_sda_EE((byte & 0x80) != 0);
             myDelay(EE_I2C_DELAY);
             eepromSCL_INpull();
             myDelay(EE_I2C_DELAY);
             eepromSCL_OUTlow();
             byte <<= 1;
             myDelay(EE_I2C_DELAY);
 		}
	eepromSDA_INpull();
	eepromSCL_INpull(); //goes high for the 9th clock
    myDelay(EE_I2C_DELAY);
    myDelay(EE_I2C_DELAY);
    myDelay(EE_I2C_DELAY);
    eepromSCL_OUTlow();
    eepromSDA_OUTlow();
    return 1;
 }
 /*********************************************************
 *   EEPROM SDA INPUT PULLUP
 *********************************************************/
 void eepromSDA_INpull(void){
   GPIO_InitTypeDef GPIO_InitStruct = {0};
   GPIO_InitStruct.Pin = EEPROM_SDA_PIN;
   GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
   GPIO_InitStruct.Pull = GPIO_PULLUP;
   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
   HAL_GPIO_Init(EEPROM_PORT, &GPIO_InitStruct);
//   while((HAL_GPIO_ReadPin(SENSOR_SDA_PORT, SENSOR_SDA_PIN))==0){}//Wait for SDA to go high.
 }
/*********************************************************
  * EEPROM SDA OUTPUT LOW
  *********************************************************/
 void eepromSDA_OUTlow(void){
   GPIO_InitTypeDef GPIO_InitStruct = {0};
   GPIO_InitStruct.Pin = EEPROM_SDA_PIN;
   GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
   GPIO_InitStruct.Pull = GPIO_NOPULL;
   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
   HAL_GPIO_Init(EEPROM_PORT, &GPIO_InitStruct);
   HAL_GPIO_WritePin(EEPROM_PORT, EEPROM_SDA_PIN, 0);//B11=SensorSDA
 }
 /*********************************************************
  * EEPROM SCL OUTPUT
  *********************************************************/
 void eepromSCL_OUT(void){
   GPIO_InitTypeDef GPIO_InitStruct = {0};
   GPIO_InitStruct.Pin = EEPROM_SCL_PIN;
   GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
   GPIO_InitStruct.Pull = GPIO_NOPULL;
   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
   HAL_GPIO_Init(EEPROM_PORT, &GPIO_InitStruct);
 }
 /*********************************************************
  * EEPROM SCL OUTPUT
  *********************************************************/
 void eepromSCL_OUTlow(void){
   GPIO_InitTypeDef GPIO_InitStruct = {0};
   GPIO_InitStruct.Pin = EEPROM_SCL_PIN;
   GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
   GPIO_InitStruct.Pull = GPIO_NOPULL;
   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
   HAL_GPIO_Init(EEPROM_PORT, &GPIO_InitStruct);
   HAL_GPIO_WritePin(EEPROM_PORT, EEPROM_SCL_PIN, 0);//B10=sensorSCL
 }
 /*********************************************************
 *   EEPROM SCL INPUT PULLUP
 *********************************************************/
 void eepromSCL_INpull(void){
   GPIO_InitTypeDef GPIO_InitStruct = {0};
   GPIO_InitStruct.Pin = EEPROM_SCL_PIN;
   GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
   GPIO_InitStruct.Pull = GPIO_PULLUP;
   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
   HAL_GPIO_Init(EEPROM_PORT, &GPIO_InitStruct);
//   while((HAL_GPIO_ReadPin(EEPROM_PORT, EEPROM_SCL_PIN))==0){}//Wait for SCL to go high.
   myDelay(EE_I2C_DELAY);
   myDelay(EE_I2C_DELAY);
   myDelay(EE_I2C_DELAY);
 }
/***********************************************************************/
/***********************************************************************/
/***********************************************************************/
/***********************************************************************/
/*      MAIN          										*/
/***********************************************************************/
/***********************************************************************/
/***********************************************************************/
/***********************************************************************/
int main(void) {
//#define MICROPY_HW_ENABLE_SDCARD 1

    unsigned char pushButtonWakeupL;
    unsigned char pushButtonWakeupC;
    unsigned char pushButtonWakeupR;
    unsigned char otherWakeupA;
    unsigned char otherWakeupB;
    unsigned char sam_tof_Wakeup;
    unsigned char wakeUpSourceBits = 0;

    #if MICROPY_HW_ENABLE_SDCARD
    bool sdcard_mounted = false;
    #endif
    bool first_soft_reset = true;

    #if defined(MICROPY_BOARD_EARLY_INIT)
    MICROPY_BOARD_EARLY_INIT();
    #endif

    HAL_Init();

    GPIO_InitTypeDef GPIO_InitStruct = {0}; // DBonham Aug 2021
    /****  UART DEBUG INIT *****/
    GPIO_InitStruct.Pin = GPIO_PIN_5 | GPIO_PIN_6; //
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;        // s
    GPIO_InitStruct.Pull = GPIO_NOPULL;            //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;   //
    GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct); //
    __HAL_RCC_UART5_CLK_ENABLE();          // REQUIRED!!
    huart5.Instance = UART5;
    huart5.Init.BaudRate = 9600;
    huart5.Init.WordLength = UART_WORDLENGTH_8B;
    huart5.Init.StopBits = UART_STOPBITS_1;
    huart5.Init.Parity = UART_PARITY_NONE;
    huart5.Init.Mode = UART_MODE_TX_RX;
    huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    huart5.Init.OverSampling = UART_OVERSAMPLING_16;
    huart5.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
    huart5.Init.ClockPrescaler = UART_PRESCALER_DIV1;
    huart5.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
    if (HAL_UART_Init(&huart5) != HAL_OK)
    {
//        Error_Handler();
    }

//SEE Micropython\ports\stm32\powerctrl.c line 1111 for register settings
    pushButtonWakeupL = READ_BIT(PWR->WKUPFR,PWR_WAKEUP_FLAG1); //PA0 PUSHBUTTON LEFT
    sam_tof_Wakeup = READ_BIT(PWR->WKUPFR,PWR_WAKEUP_FLAG2);    //PA2 SAM
	otherWakeupA = READ_BIT(PWR->WKUPFR,PWR_WAKEUP_FLAG3);      //PI8 AVAILABLE
	pushButtonWakeupC = READ_BIT(PWR->WKUPFR,PWR_WAKEUP_FLAG4); //PC13 PUSHBUTTON CENTER
	pushButtonWakeupR = READ_BIT(PWR->WKUPFR,PWR_WAKEUP_FLAG5); //PI11 PUSHBUTTON RIGHT
	otherWakeupB = READ_BIT(PWR->WKUPFR,PWR_WAKEUP_FLAG6);      //PC1 FORMERLY (PRE MVP) BLUE LED

#ifdef DO_DIAGS
    HAL_UART_Transmit(&huart5, (unsigned char*)("BOOT "), 5, 100);
#endif    
    if (pushButtonWakeupL){
        wakeUpSourceBits = 0x01;
#ifdef DO_DIAGS
        HAL_UART_Transmit(&huart5, (unsigned char*)("USER PUSHBUTTON_L\r\n"), 19, 100);
#endif    
    }else if (pushButtonWakeupC) {
        wakeUpSourceBits = 0x01;
#ifdef DO_DIAGS
        HAL_UART_Transmit(&huart5, (unsigned char*)("USER PUSHBUTTON_C\r\n"), 19, 100);
#endif    
    }else if (pushButtonWakeupR) {
        wakeUpSourceBits = 0x01;
#ifdef DO_DIAGS
        HAL_UART_Transmit(&huart5, (unsigned char*)("USER PUSHBUTTON_R\r\n"), 19, 100);
#endif    
    }else if (otherWakeupA) {
        wakeUpSourceBits = 0x10;
#ifdef DO_DIAGS
        HAL_UART_Transmit(&huart5, (unsigned char*)("OTHER_A\r\n"), 9, 100);
#endif    
    }else if (otherWakeupB) {
        wakeUpSourceBits = 0x20;
#ifdef DO_DIAGS
        HAL_UART_Transmit(&huart5, (unsigned char*)("OTHER_B\r\n"), 9, 100);
#endif    
    }else if (sam_tof_Wakeup) {
        wakeUpSourceBits = 0x40;
#ifdef DO_DIAGS
        HAL_UART_Transmit(&huart5, (unsigned char*)("SAM LIDAR\r\n"), 11, 100);
#endif    
    }else if ((RTC->ISR & 0x00000400) != 0){
        wakeUpSourceBits = 0x04;
#ifdef DO_DIAGS //don't do diags before LoRaWAN
        HAL_UART_Transmit(&huart5, (unsigned char*)("RTC\r\n"), 5, 100);
#endif                
    }else{
        wakeUpSourceBits = 0x08;
#ifdef DO_DIAGS
        HAL_UART_Transmit(&huart5, (unsigned char*)("PWR UP OR SWI\r\n"), 15, 100);
#endif    
    }

    /******* LEDs DBonham**********/
    GPIO_InitStruct.Pin = LED_PIN;                   //
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;                                   //
    GPIO_InitStruct.Pull = GPIO_NOPULL;                                           //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;                                  //
    HAL_GPIO_Init(LED_PORT, &GPIO_InitStruct);                                       //
    HAL_GPIO_WritePin(LED_PORT, LED_PIN, GPIO_PIN_SET); //SET=OFF. DBonham Aug 2021
    /******* SD_PWRC K2 DBonham **********/
    __HAL_RCC_GPIOK_CLK_ENABLE();
    GPIO_InitStruct.Pin = GPIO_PIN_2;           //
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;      //
    GPIO_InitStruct.Pull = GPIO_NOPULL;        //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW; //
    HAL_GPIO_Init(GPIOK, &GPIO_InitStruct);      //
    HAL_GPIO_WritePin(GPIOK, GPIO_PIN_2, 1);    //G9 = SD_PWRC
    /******* WKUP_PIN2 C13 DBonham **********/
    GPIO_InitStruct.Pin = GPIO_PIN_13;           //
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;      //
    GPIO_InitStruct.Pull = GPIO_PULLDOWN;        //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW; //
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);      //
    /******* WU_BIG A2 DBonham **********/
    GPIO_InitStruct.Pin = GPIO_PIN_2;            //
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;      //
    GPIO_InitStruct.Pull = GPIO_PULLUP;          //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW; //
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);      //
    /******* WU_TINY A3 DBonham **********/
    GPIO_InitStruct.Pin = GPIO_PIN_3;                   //
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;         //
    GPIO_InitStruct.Pull = GPIO_NOPULL;                 //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;        //
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);             //
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_SET); //
    /******* BIG_TINY_DAT B0 DBonham **********/
    GPIO_InitStruct.Pin = GPIO_PIN_0;            //
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;      //
    GPIO_InitStruct.Pull = GPIO_NOPULL;          //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW; //
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);      //
    /******* BIG_TINY_CLK G12 DBonham **********/
    GPIO_InitStruct.Pin = GPIO_PIN_12;           //
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;      //
    GPIO_InitStruct.Pull = GPIO_NOPULL;          //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW; //
    HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);      //
    /******* TINY_RESET A1 DBonham **********/
    GPIO_InitStruct.Pin = GPIO_PIN_1;            //
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;      //
    GPIO_InitStruct.Pull = GPIO_PULLUP;          //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW; //
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);      //
    /******* SENS_PWRC D13 DBonham **********/
    GPIO_InitStruct.Pin = GPIO_PIN_13;                     //
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;            //
    GPIO_InitStruct.Pull = GPIO_NOPULL;                    //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;           //
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);                //
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET); //
    /******* SENS_SCL B10 DBonham **********/
    GPIO_InitStruct.Pin = GPIO_PIN_10;                     //
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;                //
    GPIO_InitStruct.Pull = GPIO_PULLDOWN;                  //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;           //
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);                //
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_RESET); //
    /******* SENS_SDA B11 DBonham **********/
    GPIO_InitStruct.Pin = GPIO_PIN_11;                     //
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;                //
    GPIO_InitStruct.Pull = GPIO_PULLDOWN;                  //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;           //
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);                //
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_RESET); //
    /******* USB5V A9 DBonham **********/
    GPIO_InitStruct.Pin = GPIO_PIN_9;            // A9
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;      //
    GPIO_InitStruct.Pull = GPIO_NOPULL;          //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW; //
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);      //
    /******* CAM_PWRC D3 **********/
    GPIO_InitStruct.Pin = OMV_CAM_PWRC_PIN;                               // D3=CAM_PWRC. DBonham Aug 2021
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;                           // DBonham Aug 2021
    GPIO_InitStruct.Pull = GPIO_NOPULL;                                   // DBonham Aug 2021
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;                          // DBonham Aug 2021
    HAL_GPIO_Init(OMV_CAM_PWRC_PORT, &GPIO_InitStruct);                   // DBonham Aug 2021
    HAL_GPIO_WritePin(OMV_CAM_PWRC_PORT, OMV_CAM_PWRC_PIN, GPIO_PIN_SET); // DBonham Aug 2021
    /******* SDRAM_PWRC **********/
    __HAL_RCC_GPIOJ_CLK_ENABLE();
    GPIO_InitStruct.Pin = OMV_DRAM_PWRC_PIN;                                // FDTV1 B1, FDTV2 J10 = DRAM_PWRC. DBonham Aug 2021
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;                             // DBonham Aug 2021
    GPIO_InitStruct.Pull = GPIO_NOPULL;                                     // DBonham Aug 2021
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;                            // DBonham Aug 2021
    HAL_GPIO_Init(OMV_DRAM_PWRC_PORT, &GPIO_InitStruct);                    // DBonham Aug 2021
    HAL_GPIO_WritePin(OMV_DRAM_PWRC_PORT, OMV_DRAM_PWRC_PIN, GPIO_PIN_SET); // DBonham Aug 2021
    /******* LRW_PWRC C3 DBonham **********/
    GPIO_InitStruct.Pin = OMV_LRW_PWRC_PIN;                               // D3=CAM_PWRC. DBonham Aug 2021
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;                           // DBonham Aug 2021
    GPIO_InitStruct.Pull = GPIO_NOPULL;                                   // DBonham Aug 2021
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;                          // DBonham Aug 2021
    HAL_GPIO_Init(OMV_LRW_PWRC_PORT, &GPIO_InitStruct);                   // DBonham Aug 2021
    HAL_GPIO_WritePin(OMV_LRW_PWRC_PORT, OMV_LRW_PWRC_PIN, GPIO_PIN_SET); // DBonham Aug 2021
    /******* LCD DBonham**********/
    GPIO_InitStruct.Pin = OMV_LCD_PWRC_PIN;             //
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;         //
    GPIO_InitStruct.Pull = GPIO_NOPULL;                 //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;        //
    HAL_GPIO_Init(OMV_LCD_PWRC_PORT, &GPIO_InitStruct); //
    OMV_LCD_PWRC_LOW();                                // v.2 board is PFET

    GPIO_InitStruct.Pin = OMV_LCD_SI_PIN2;             //
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;       //
    GPIO_InitStruct.Pull = GPIO_NOPULL;               //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;      //
    HAL_GPIO_Init(OMV_LCD_SI_PORT2, &GPIO_InitStruct); //
    OMV_LCD_SI_LOW();                                 //

    GPIO_InitStruct.Pin = OMV_LCD_SCL_PIN;             //
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;        //
    GPIO_InitStruct.Pull = GPIO_NOPULL;                //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;       //
    HAL_GPIO_Init(OMV_LCD_SCL_PORT, &GPIO_InitStruct); //
    OMV_LCD_SCL_LOW();                                 //

    GPIO_InitStruct.Pin = OMV_LCD_CSB_PIN;             //
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;        //
    GPIO_InitStruct.Pull = GPIO_NOPULL;                //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;       //
    HAL_GPIO_Init(OMV_LCD_CSB_PORT, &GPIO_InitStruct); //
    OMV_LCD_CSB_LOW();                                 //

    GPIO_InitStruct.Pin = OMV_LCD_RS_PIN;             //
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;       //
    GPIO_InitStruct.Pull = GPIO_NOPULL;               //
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;      //
    HAL_GPIO_Init(OMV_LCD_RS_PORT, &GPIO_InitStruct); //
    OMV_LCD_RS_LOW();                                 //

    eepromWriteWakeUpSource(wakeUpSourceBits);

    /****  WAKEUP PINS *****/
    PWREx_WakeupPinTypeDef sPinParams;
    HAL_PWR_EnableBkUpAccess();                 //MUST HAVE THIS BEFORE SET_BIT(RTC...) DBonham Feb.2022
    __HAL_PWR_CLEAR_FLAG(PWR_FLAG_WU);
    HAL_PWR_DisableWakeUpPin(PWR_WAKEUP_PIN1);	//WAKEUP_PIN1=PA0=WKUP0 From Pushbutton LEFT.
    HAL_PWR_DisableWakeUpPin(PWR_WAKEUP_PIN2);	//WAKEUP_PIN2=PA2=WKUP1 From SAM.
    HAL_PWR_DisableWakeUpPin(PWR_WAKEUP_PIN3);	//WAKEUP_PIN3=PC13=WKUP2 From Pushbutton CENTER.
    HAL_PWR_DisableWakeUpPin(PWR_WAKEUP_PIN5);	//WAKEUP_PIN5=PI11=WKUP4 From Pushbutton RIGHT.
    HAL_PWREx_ClearWakeupFlag(PWR_WAKEUP_FLAG1 | PWR_WAKEUP_FLAG2 | PWR_WAKEUP_FLAG3 | PWR_WAKEUP_FLAG5);	//WKUPF 1..6
    /* Enable WakeUp Pin PWR_WAKEUP_PIN4 connected to PC.13 (STM DATASHEET IS WRONG!! PC13 IS WKUP4 NOT WKUP2!!!*/
    /* Do this here in case we jump to a script and go to sleep from there. */
    sPinParams.WakeUpPin    = PWR_WAKEUP_PIN1;	//WAKEUP_PIN1=PA0=WKUP0 From Pushbutton LEFT.
    sPinParams.PinPolarity  = PWR_WAKEUP_PIN1_HIGH;
    sPinParams.PinPull      = PWR_PIN_NO_PULL;
    HAL_PWREx_EnableWakeUpPin(&sPinParams);	//WKUPEN 1..6*/

    sPinParams.WakeUpPin    = PWR_WAKEUP_PIN2;	//WAKEUP_PIN2=PA2=WKUP1 From SAM.
    sPinParams.PinPolarity  = PWR_WAKEUP_PIN2_LOW;
    sPinParams.PinPull      = PWR_PIN_PULL_UP;
    HAL_PWREx_EnableWakeUpPin(&sPinParams);	//WKUPEN 1..6*/    #if MICROPY_HW_SDRAM_SIZE

    /* Clear the WU FLAG */
    __HAL_PWR_CLEAR_FLAG(PWR_FLAG_WU);
 //   HAL_PWREx_ClearWakeupFlag(PWR_WAKEUP_FLAG1 | PWR_WAKEUP_FLAG2 | PWR_WAKEUP_FLAG3 | PWR_WAKEUP_FLAG5);	//WKUPF 1..6
    HAL_PWR_EnableWakeUpPin(PWR_WAKEUP_PIN1);	//WAKEUP_PIN1=PA0=WKUP0 From Pushbutton LEFT.
    HAL_PWR_EnableWakeUpPin(PWR_WAKEUP_PIN2);	//WAKEUP_PIN2=PA2=WKUP1 From SAM.

    sdram_init();

    #if MICROPY_HW_SDRAM_STARTUP_TEST
    sdram_test(false);
 //   HAL_UART_Transmit(&huart5, (unsigned char*)("FW A SDRAM TEST\r\n"), 17, 100);    //Y
    #endif

    // Basic sub-system init
    led_init();
    pendsv_init();

    // Re-enable IRQs (disabled by bootloader)
    __enable_irq();

soft_reset:
//    HAL_UART_Transmit(&huart5, (unsigned char*)("FW B SOFT RESET\r\n"), 17, 100);    //YY

    #if defined(MICROPY_HW_LED4)
    led_state(LED_IR, 0);
//    HAL_UART_Transmit(&huart5, (unsigned char*)("FW C IR LED\r\n"), 13, 100); //YY
    #endif

    machine_init();

    // Stack limit should be less than real stack size, so we have a
    // chance to recover from limit hit. (Limit is measured in bytes)
    mp_stack_set_top(&_estack);
    mp_stack_set_limit((char *) &_estack - (char *) &_sstack - 1024);

    // GC init
    gc_init(&_heap_start, &_heap_end);

    // Micro Python init
    mp_init();
    MP_STATE_PORT(pyb_stdio_uart) = NULL;


    // Initialise low-level sub-systems. Here we need to do the very basic
    // things like zeroing out memory and resetting any of the sub-systems.
    //py_fir_init0();
    #if MICROPY_PY_TV
    py_tv_init0();
//    HAL_UART_Transmit(&huart5, (unsigned char*)("FW D PY TV\r\n"), 12, 100);  //YY
    #endif

    imlib_init_all();
    readline_init0();
    pin_init0();//okay to here
    extint_init0();
    timer_init0();
    uart_init0();//okay to here

    i2c_init0();
    spi_init0();
    fb_alloc_init0();
    omv_gpio_init0();
    framebuffer_init0();
    sensor_init0();
    dma_alloc_init0();

    #ifdef IMLIB_ENABLE_IMAGE_FILE_IO
    file_buffer_init0();
//    HAL_UART_Transmit(&huart5, (unsigned char*)("FW E FILE BUFFER\r\n"), 18, 100);   //YY
    #endif
    #if MICROPY_HW_ENABLE_SERVO
    servo_init();
//    HAL_UART_Transmit(&huart5, (unsigned char*)("FW F SERVO\r\n"), 12, 100);  //YY
    #endif
    usbdbg_init();
    #if MICROPY_HW_ENABLE_SDCARD
    sdcard_init();
//    HAL_UART_Transmit(&huart5, (unsigned char*)("FW G SD INIT\r\n"), 14, 100);    //YY
    #endif
    rtc_init_start(false);

    // Initialize the sensor and check the result after
    // mounting the file-system to log errors (if any).
    if (first_soft_reset) {
        sensor_init();
//        HAL_UART_Transmit(&huart5, (unsigned char*)("FW H AFTER SENSOR INIT\r\n"), 24, 100);   //YN
    }

    pyb_usb_init0();

    // Remove the BASEPRI masking (if any)
    irq_set_base_priority(0);

    #if MICROPY_HW_ENABLE_SDCARD
    // Initialize storage
    if (sdcard_is_present()) {
//        HAL_UART_Transmit(&huart5, (unsigned char*)("FW I SD CARD PRESENT\r\n"), 22, 100);   //YY
        // Init the vfs object
        vfs_fat->blockdev.flags = 0;
        sdcard_init_vfs(vfs_fat, 0);

        // Try to mount the SD card
        FRESULT res = f_mount(&vfs_fat->fatfs);
        if (res != FR_OK) {
            sdcard_mounted = false;
        } else {
            sdcard_mounted = true;
            // Set USB medium to SD
            pyb_usb_storage_medium = PYB_USB_STORAGE_MEDIUM_SDCARD;
//            HAL_UART_Transmit(&huart5, (unsigned char*)("FW J SD MOUNTED=TRUE\r\n"), 22, 100); //YY
        }
    }else{
        HAL_UART_Transmit(&huart5, (unsigned char*)("FW BAD J SD CARD NOT PRESENT\r\n"), 30, 100); //NN
    }
    #endif

    #if MICROPY_HW_ENABLE_SDCARD
    if (sdcard_mounted == false) {
        HAL_UART_Transmit(&huart5, (unsigned char*)("FW BAD J SD NOT MOUNTED\r\n"), 25, 100);    //NN because found and mounted SD card
    #endif

    HAL_UART_Transmit(&huart5, (unsigned char*)("FW BAD J STORAGE INIT\r\n"), 23, 100);  //NN because found and mounted SD card

    storage_init();

    // init the vfs object
    vfs_fat->blockdev.flags = 0;
    pyb_flash_init_vfs(vfs_fat);

    // Try to mount the flash
    FRESULT res = f_mount(&vfs_fat->fatfs);
    HAL_UART_Transmit(&huart5, (unsigned char*)("FW BAD J MOUNTED FLASH\r\n"), 24, 100); //NN because found and mounted SD card


    if (res == FR_NO_FILESYSTEM) {
        // Create a fresh filesystem.
        led_state(LED_RED, 1);
        bootutils_init_filesystem(vfs_fat);
        led_state(LED_RED, 0);
        // Flush storage
        storage_flush();
        HAL_UART_Transmit(&huart5, (unsigned char*)("FW BAD J CREATED FILE SYSTEM\r\n"), 30, 100);   //NN because found and mounted SD card
    } else if (res != FR_OK) {
        __fatal_error("Could not access LFS\n");
    }

    // Set USB medium to flash
    pyb_usb_storage_medium = PYB_USB_STORAGE_MEDIUM_FLASH;
    #if MICROPY_HW_ENABLE_SDCARD
}   //end of if did not find SD card
#if MICROPY_HW_HAS_FLASH
else {
//    HAL_UART_Transmit(&huart5, (unsigned char*)("FW K STORAGE INIT WITH FLASH\r\n"), 30, 100);  //YY
    // The storage should always be initialized on boards that have
    // an external flash, to make sure the flash is memory-mapped.
    storage_init();
}
#endif  //has flash
    #endif //has SDcard
    // Mount the storage device (there should be no other devices mounted at this point)
    // we allocate this structure on the heap because vfs->next is a root pointer.
    mp_vfs_mount_t *vfs = m_new_obj_maybe(mp_vfs_mount_t);
    if (vfs == NULL) {
        __fatal_error("Failed to alloc memory for vfs mount\n");
       HAL_UART_Transmit(&huart5, (unsigned char*)("FW BAD K VFS\r\n"), 14, 100);  //NN

    }
//    HAL_UART_Transmit(&huart5, (unsigned char*)("FW L AFTER FVS\r\n"), 16, 100);  //YY

    vfs->str = "/";
    vfs->len = 1;
    vfs->obj = MP_OBJ_FROM_PTR(vfs_fat);
    vfs->next = NULL;
    MP_STATE_VM(vfs_mount_table) = vfs;
    MP_STATE_PORT(vfs_cur) = vfs;

    // Mark the filesystem as an OpenMV storage.
    file_ll_touch("/.openmv_disk");

    // Parse OpenMV configuration file.
    openmv_config_t openmv_config;
    memset(&openmv_config, 0, sizeof(openmv_config));
    ini_parse(&vfs_fat->fatfs, "/openmv.config", ini_handler_callback, &openmv_config);

    // Init wifi debugging if enabled and on first soft-reset only.
    openmv_config.wifidbg = false;
 
    // Init USB device to default setting if it was not already configured
    if (!(pyb_usb_flags & PYB_USB_FLAG_USB_MODE_CALLED)) {
        pyb_usb_dev_init(pyb_usb_dev_detect(), MICROPY_HW_USB_VID,
        MICROPY_HW_USB_PID_CDC_MSC, USBD_MODE_CDC_MSC, 0, NULL, NULL);
//        HAL_UART_Transmit(&huart5, (unsigned char*)("FW M NO PYB USB FLAGS\r\n"), 23, 100);  //YY

    }

    // Run boot.py script.
    bool interrupted = bootutils_exec_bootscript("bootFDT.py", true, false);

    // Run main.py script on first soft-reset.
    if (first_soft_reset && !interrupted && mp_vfs_import_stat("main.py")) {
        HAL_UART_Transmit(&huart5, (unsigned char*)("FW O RUN MAIN.PY\r\n"), 18, 100);  //NN because found and mounted SD card
        bootutils_exec_bootscript("main.py", true, openmv_config.wifidbg);
        goto soft_reset_exit;
    }

    do {
        usbdbg_init();

    HAL_UART_Transmit(&huart5, (unsigned char*)("FW P USB DBG INIT\r\n"), 19, 100);

        // If there's no script ready, just re-exec REPL
        while (!usbdbg_script_ready()) {
            HAL_UART_Transmit(&huart5, (unsigned char*)("FW Q NO DBG SCRIPT\r\n"), 20, 100);
            nlr_buf_t nlr;

            if (nlr_push(&nlr) == 0) {
                // enable IDE interrupt
                usbdbg_set_irq_enabled(true);

                // run REPL
                if (pyexec_mode_kind == PYEXEC_MODE_RAW_REPL) {
                    if (pyexec_raw_repl() != 0) {
                        break;
                    }
                } else {
                    if (pyexec_friendly_repl() != 0) {
                        break;
                    }
                }

                nlr_pop();
            }//if nlr_push
        }//hile no usbdbg script
    HAL_UART_Transmit(&huart5, (unsigned char*)("FW R\r\n"), 6, 100);

        if (usbdbg_script_ready()) {
            HAL_UART_Transmit(&huart5, (unsigned char*)("FW S\r\n"), 6, 100);
            nlr_buf_t nlr;
            if (nlr_push(&nlr) == 0) {
                // Enable IDE interrupts
                usbdbg_set_irq_enabled(true);
                #if OMV_WIFIDBG_ENABLE && MICROPY_PY_WINC1500
                wifidbg_set_irq_enabled(openmv_config.wifidbg);
                #endif
                // Execute the script.
                pyexec_str(usbdbg_get_script(), true);
                // Disable IDE interrupts
                usbdbg_set_irq_enabled(false);
                nlr_pop();
            } else {
                mp_obj_print_exception(&mp_plat_print, (mp_obj_t) nlr.ret_val);
            }

            if (usbdbg_is_busy() && nlr_push(&nlr) == 0) {
                // Enable IDE interrCrazupt
                usbdbg_set_irq_enabled(true);
                #if OMV_WIFIDBG_ENABLE && MICROPY_PY_WINC1500
                wifidbg_set_irq_enabled(openmv_config.wifidbg);
                #endif
                // Wait for the current command to finish.
                usbdbg_wait_for_command(1000);
                // Disable IDE interrupts
                usbdbg_set_irq_enabled(false);
                nlr_pop();
            }
        }

    HAL_UART_Transmit(&huart5, (unsigned char*)("FW T\r\n"), 6, 100);
    } while (openmv_config.wifidbg == true);

soft_reset_exit:
    // soft reset
    mp_printf(&mp_plat_print, "MPY: soft reboot\n");
    HAL_UART_Transmit(&huart5, (unsigned char*)("FW U\r\n"), 6, 100);

    // Flush filesystem storage.
    storage_flush();

    // Call GC sweep first, before deinitializing networking drivers
    // such as WINC/CYW43 which need to be active to close sockets
    // when their finalizers are called by GC.
    gc_sweep_all();

    // Disable all other IRQs except Systick
    irq_set_base_priority(IRQ_PRI_SYSTICK + 1);

    #if MICROPY_PY_LWIP
//    systick_disable_dispatch(SYSTICK_DISPATCH_LWIP);
    #endif
    #if MICROPY_PY_BLUETOOTH
//    mp_bluetooth_deinit();
    #endif
    #if MICROPY_PY_NETWORK
    mod_network_deinit();
    #endif
    timer_deinit();
    i2c_deinit_all();
    spi_deinit_all();
    uart_deinit_all();
    #if MICROPY_HW_ENABLE_CAN
    can_deinit_all();
    #endif
    #if MICROPY_PY_THREAD
    pyb_thread_deinit();
    #endif
    #if MICROPY_PY_AUDIO
    py_audio_deinit();
    #endif
    imlib_deinit_all();

    mp_deinit();

    first_soft_reset = false;
    goto soft_reset;
}